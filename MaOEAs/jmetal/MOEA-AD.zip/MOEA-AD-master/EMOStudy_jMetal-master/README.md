# EMOStudy_jMetal

This package contains the following EMO algorithms:
MOEA/AD (http://arxiv.org/abs/1704.02340)
MOEA/D-AOOSTM (http://ieeexplore.ieee.org/document/7837621/)
MOEA/D-AMOSTM (http://ieeexplore.ieee.org/document/7837621/)
MOEA/D-STM2L (http://ieeexplore.ieee.org/document/7379434/)
MOEA/D-STM (http://ieeexplore.ieee.org/document/6678563/)
MOEA/D-IR (http://ieeexplore.ieee.org/document/6975090/)
and other algorithms provided in jMetal 4.5.2 (http://jmetal.sourceforge.net/)


